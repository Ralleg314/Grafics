var a = 5,
    b =  a > 0 && a < 4;
