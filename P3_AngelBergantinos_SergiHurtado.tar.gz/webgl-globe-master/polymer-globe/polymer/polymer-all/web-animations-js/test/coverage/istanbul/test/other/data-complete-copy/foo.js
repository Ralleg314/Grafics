module.exports = {
    foo: function () { return 'foo'; }
};

