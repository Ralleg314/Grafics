function test() {
    /*
     * Leading comment
     */

    /*
     *
     * Leading comment 2
     *
     */

    var i = 20;
    /*
     * Trailing comment
     */

    /*
     *
     * Trailing comment 2
     *
     */
}
