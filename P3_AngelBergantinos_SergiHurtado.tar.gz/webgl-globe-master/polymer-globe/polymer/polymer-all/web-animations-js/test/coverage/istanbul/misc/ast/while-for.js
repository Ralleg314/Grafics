var i = 10,
    j;
while (i--)
    for (j=0; j<i; j++)
        console.log(j);
