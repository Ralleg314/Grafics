module.exports = {
    baz: function () { return 'baz'; }
};
