var x = args[0];
output = x;

