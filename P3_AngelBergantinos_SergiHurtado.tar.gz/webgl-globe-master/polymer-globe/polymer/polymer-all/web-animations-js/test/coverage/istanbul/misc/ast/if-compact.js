if (20 > 10) console.log('>10'); else if (x < 10) console.log('<10'); else console.log('10');
