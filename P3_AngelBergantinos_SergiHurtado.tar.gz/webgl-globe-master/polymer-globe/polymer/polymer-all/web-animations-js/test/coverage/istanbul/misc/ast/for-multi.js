for (var i = 0, j=0; i<10; i++, j++)
    console.log(i + j);
